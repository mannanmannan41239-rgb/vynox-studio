package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// VYNOX Studio Dark Theme Palette
val VynoxBackground = Color(0xFF080A0F)
val VynoxSurface = Color(0xFF10141E)
val VynoxSurfaceElevated = Color(0xFF161C2A)
val VynoxSurfaceHighlight = Color(0xFF1C2436)
val VynoxBorder = Color(0xFF1F293D)
val VynoxBorderSubtle = Color(0x3338BDF8)

// Brand Gradients & Accents
val VynoxPrimary = Color(0xFF6366F1) // Electric Indigo
val VynoxPrimaryVariant = Color(0xFF4F46E5)
val VynoxSecondary = Color(0xFF8B5CF6) // Royal Violet
val VynoxTertiary = Color(0xFF38BDF8) // Cyan Glow
val VynoxAccentPink = Color(0xFFEC4899)
val VynoxAccentAmber = Color(0xFFF59E0B) // Crown Gold
val VynoxAccentEmerald = Color(0xFF10B981) // Success / Online

// Text Colors
val VynoxTextPrimary = Color(0xFFFFFFFF)
val VynoxTextSecondary = Color(0xFF94A3B8)
val VynoxTextMuted = Color(0xFF64748B)

// Tool Category Colors
val ToolCyan = Color(0xFF06B6D4)
val ToolViolet = Color(0xFF8B5CF6)
val ToolIndigo = Color(0xFF6366F1)
val ToolRose = Color(0xFFF43F5E)
val ToolAmber = Color(0xFFF59E0B)
val ToolEmerald = Color(0xFF10B981)
