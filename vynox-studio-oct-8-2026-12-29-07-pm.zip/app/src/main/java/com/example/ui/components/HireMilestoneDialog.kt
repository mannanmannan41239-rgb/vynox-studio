package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EditorCreator
import com.example.model.VynoxMockData
import com.example.ui.theme.*

@Composable
fun HireMilestoneDialog(
    creator: EditorCreator,
    onDismiss: () -> Unit,
    onPaymentSuccess: () -> Unit
) {
    var isPaid by remember { mutableStateOf(false) }
    val milestones = remember { VynoxMockData.invoices }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VynoxSurfaceElevated,
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(creator.avatarBgColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = creator.avatarInitials,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column {
                    Text(
                        text = creator.name,
                        color = VynoxTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Milestones & Escrow",
                        color = VynoxTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Project Milestones:",
                    color = VynoxTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                milestones.forEach { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = VynoxSurfaceHighlight),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = item.title,
                                    color = VynoxTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = item.date,
                                    color = VynoxTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = item.amount,
                                color = VynoxTertiary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                if (isPaid) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = VynoxAccentEmerald.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VynoxAccentEmerald),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = VynoxAccentEmerald,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Milestone funded into Escrow!",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (!isPaid) {
                Button(
                    onClick = {
                        isPaid = true
                        onPaymentSuccess()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VynoxPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("pay_milestone_button")
                ) {
                    Text("Fund Escrow ($15.00)")
                }
            } else {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = VynoxSurfaceHighlight),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("Close")
                }
            }
        },
        dismissButton = {
            if (!isPaid) {
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = VynoxTextSecondary)
                }
            }
        }
    )
}
