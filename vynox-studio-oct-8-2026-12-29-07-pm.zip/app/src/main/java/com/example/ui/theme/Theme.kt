package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VynoxColorScheme = darkColorScheme(
    primary = VynoxPrimary,
    onPrimary = Color.White,
    primaryContainer = VynoxSurfaceElevated,
    onPrimaryContainer = Color.White,
    secondary = VynoxSecondary,
    onSecondary = Color.White,
    tertiary = VynoxTertiary,
    onTertiary = Color.Black,
    background = VynoxBackground,
    onBackground = VynoxTextPrimary,
    surface = VynoxSurface,
    onSurface = VynoxTextPrimary,
    surfaceVariant = VynoxSurfaceElevated,
    onSurfaceVariant = VynoxTextSecondary,
    outline = VynoxBorder,
    outlineVariant = VynoxBorderSubtle
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Keep consistent high-fidelity VYNOX studio theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VynoxColorScheme,
        typography = Typography,
        content = content
    )
}
