package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EditorCreator
import com.example.model.QuickTool
import com.example.ui.theme.*

@Composable
fun VynoxTopHeader(
    onAvatarClick: () -> Unit,
    onProBadgeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "VYNOX",
                color = VynoxTextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
            Text(
                text = "Studio",
                color = VynoxTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.5.sp
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // PRO Crown Badge
            Surface(
                onClick = onProBadgeClick,
                shape = RoundedCornerShape(12.dp),
                color = VynoxAccentAmber.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, VynoxAccentAmber.copy(alpha = 0.5f)),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("pro_badge_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "Pro Status",
                        tint = VynoxAccentAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "PRO",
                        color = VynoxAccentAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // User Profile Avatar
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .border(2.dp, Brush.linearGradient(listOf(VynoxPrimary, VynoxTertiary)), CircleShape)
                    .background(VynoxSurfaceElevated)
                    .clickable(onClick = onAvatarClick)
                    .testTag("user_avatar_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "JD",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun VynoxGreetingSection(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp)
    ) {
        Text(
            text = "Good morning.",
            color = VynoxTextSecondary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Normal
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Let's create something\namazing today",
                color = VynoxTextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 30.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = VynoxTertiary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun VynoxSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "Search templates, tools...",
    onClear: () -> Unit = {}
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .height(52.dp)
            .testTag("search_bar_surface"),
        shape = RoundedCornerShape(26.dp),
        color = VynoxSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = VynoxTextMuted,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) {
                    Text(
                        text = placeholder,
                        color = VynoxTextMuted,
                        fontSize = 14.sp
                    )
                }
                androidx.compose.foundation.text.BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = VynoxTextPrimary,
                        fontSize = 14.sp
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_text_input")
                )
            }
            if (query.isNotEmpty()) {
                IconButton(
                    onClick = onClear,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear",
                        tint = VynoxTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun VynoxPromoBanner(
    creators: List<EditorCreator>,
    onBrowseClick: () -> Unit,
    onFindEditorsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("promo_banner_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = VynoxSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.horizontalGradient(
                listOf(VynoxPrimary.copy(alpha = 0.5f), VynoxTertiary.copy(alpha = 0.2f), VynoxBorder)
            )
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.radialGradient(
                        colors = listOf(VynoxPrimary.copy(alpha = 0.12f), Color.Transparent),
                        radius = 400f
                    )
                )
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left text & action
                Column(
                    modifier = Modifier.weight(1.3f)
                ) {
                    Text(
                        text = "Looking for a Pro?",
                        color = VynoxTextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Hire top Vynox Editors.",
                        color = VynoxTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onBrowseClick,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VynoxPrimary
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("browse_creators_button")
                    ) {
                        Text(
                            text = "Browse Creators",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Right Avatars & Action Button
                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.weight(0.9f)
                ) {
                    // Avatar stack
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy((-8).dp)
                    ) {
                        creators.take(3).forEach { creator ->
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(creator.avatarBgColor)
                                    .border(2.dp, VynoxSurfaceElevated, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = creator.avatarInitials,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Circular Find Editors action button
                    Surface(
                        onClick = onFindEditorsClick,
                        shape = RoundedCornerShape(16.dp),
                        color = VynoxSurfaceHighlight,
                        border = androidx.compose.foundation.BorderStroke(1.dp, VynoxTertiary.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .size(46.dp)
                            .testTag("find_editors_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Find Editors",
                                tint = VynoxTertiary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickToolCard(
    tool: QuickTool,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .testTag("quick_tool_${tool.id}")
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = VynoxSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            // Optional Badge (e.g. AI / NEW)
            if (tool.badge != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = tool.accentColor.copy(alpha = 0.25f),
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Text(
                        text = tool.badge,
                        color = tool.accentColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Icon with subtle glow background
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(tool.accentColor.copy(alpha = 0.16f))
                        .border(1.dp, tool.accentColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getToolIcon(tool.iconType),
                        contentDescription = tool.title,
                        tint = tool.accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Column {
                    Text(
                        text = tool.title,
                        color = VynoxTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tool.subtitle,
                        color = VynoxTextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

fun getToolIcon(type: String): ImageVector {
    return when (type) {
        "grid" -> Icons.Default.GridView
        "magic" -> Icons.Default.AutoFixHigh
        "ai" -> Icons.Default.Psychology
        "video" -> Icons.Default.Videocam
        "sparkles" -> Icons.Default.AutoAwesome
        "palette" -> Icons.Default.Palette
        "scissors" -> Icons.Default.ContentCut
        "waveform" -> Icons.Default.GraphicEq
        "script" -> Icons.Default.Description
        else -> Icons.Default.Build
    }
}

@Composable
fun VynoxBottomNav(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val navItems = listOf(
        Triple(0, "Home", Icons.Default.Home),
        Triple(1, "Templates", Icons.Default.GridView),
        Triple(2, "Projects", Icons.Default.FolderOpen),
        Triple(3, "Find Editors", Icons.Default.PersonSearch)
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        color = VynoxSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEach { (index, label, icon) ->
                val isSelected = selectedTab == index
                val itemColor = if (isSelected) VynoxPrimary else VynoxTextMuted

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onTabSelected(index) }
                        .padding(vertical = 6.dp)
                        .testTag("nav_item_$index"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .height(30.dp)
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(VynoxPrimary.copy(alpha = 0.2f))
                            )
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = itemColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = label,
                        color = itemColor,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}
