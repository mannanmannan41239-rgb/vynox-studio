package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiGeneratorSheet(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf("Text to Video") }
    val modes = listOf("Text to Video", "Image to Video", "Script to Video")

    var promptText by remember {
        mutableStateOf("Cinematic drone shot of futuristic glowing metropolis in rain, 8K hyper-detailed, neon reflections")
    }

    var selectedStyle by remember { mutableStateOf("Cinematic") }
    val styles = listOf("Cinematic", "Cyberpunk", "Anime", "Photoreal", "Film Noir")

    var selectedAspect by remember { mutableStateOf("16:9") }
    val aspectRatios = listOf("16:9", "9:16", "1:1")

    var isGenerating by remember { mutableStateOf(false) }
    var generationProgress by remember { mutableFloatStateOf(0f) }
    var generationComplete by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = VynoxSurfaceElevated,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(VynoxBorder)
            )
        }
    ) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .navigationBarsPadding()
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AI Generator",
                    color = VynoxTextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = VynoxTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Mode Tabs (Text to Video, Image to Video, Script to Video)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(VynoxSurfaceHighlight)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                modes.forEach { mode ->
                    val isSelected = selectedTab == mode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) VynoxPrimary else Color.Transparent)
                            .clickable { selectedTab = mode }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode,
                            color = if (isSelected) Color.White else VynoxTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Prompt Box
            Text(
                text = "Describe your vision",
                color = VynoxTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = promptText,
                onValueChange = { promptText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .testTag("ai_prompt_input"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VynoxPrimary,
                    unfocusedBorderColor = VynoxBorder,
                    focusedTextColor = VynoxTextPrimary,
                    unfocusedTextColor = VynoxTextPrimary,
                    cursorColor = VynoxTertiary
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Style Selector Row
            Text(
                text = "Aesthetic Style",
                color = VynoxTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                styles.take(3).forEach { style ->
                    val isSelected = selectedStyle == style
                    Surface(
                        onClick = { selectedStyle = style },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) VynoxPrimary.copy(alpha = 0.2f) else VynoxSurfaceHighlight,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) VynoxPrimary else VynoxBorder
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = style,
                                color = if (isSelected) VynoxTertiary else VynoxTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Aspect Ratio Selector
            Text(
                text = "Aspect Ratio",
                color = VynoxTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                aspectRatios.forEach { aspect ->
                    val isSelected = selectedAspect == aspect
                    Surface(
                        onClick = { selectedAspect = aspect },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) VynoxSecondary.copy(alpha = 0.2f) else VynoxSurfaceHighlight,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) VynoxSecondary else VynoxBorder
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = aspect,
                                color = if (isSelected) Color.White else VynoxTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Generation Progress or CTA
            if (isGenerating) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LinearProgressIndicator(
                        progress = { generationProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = VynoxPrimary,
                        trackColor = VynoxBorder
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Rendering neural frames... ${(generationProgress * 100).toInt()}%",
                        color = VynoxTextSecondary,
                        fontSize = 12.sp
                    )
                }
            } else if (generationComplete) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = VynoxAccentEmerald.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VynoxAccentEmerald.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = VynoxAccentEmerald
                        )
                        Text(
                            text = "Generation finished! Added to Project Hub.",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                Button(
                    onClick = {
                        isGenerating = true
                        generationProgress = 0f
                        coroutineScope.launch {
                            for (i in 1..10) {
                                delay(200)
                                generationProgress = i / 10f
                            }
                            isGenerating = false
                            generationComplete = true
                        }
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = VynoxPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("ai_generate_action_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Generate Video (5 Credits)",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}
