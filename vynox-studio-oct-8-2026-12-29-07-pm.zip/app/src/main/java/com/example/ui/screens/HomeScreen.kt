package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onToolClick: (QuickTool) -> Unit,
    onSeeAllToolsClick: () -> Unit,
    onBrowseCreatorsClick: () -> Unit,
    onProjectClick: (ProjectItem) -> Unit,
    onCreateProjectClick: () -> Unit,
    onOpenAiGenerator: () -> Unit,
    onAvatarClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val quickTools = remember { VynoxMockData.quickTools }
    val creators = remember { VynoxMockData.creators }
    val projects = remember { VynoxMockData.projects }

    // Filter tools if user types in search bar
    val filteredTools = remember(searchQuery) {
        if (searchQuery.isBlank()) quickTools
        else quickTools.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                    it.subtitle.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VynoxBackground)
            .statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // 1. Header (VYNOX Studio + Crown + Avatar)
        item {
            VynoxTopHeader(
                onAvatarClick = onAvatarClick,
                onProBadgeClick = onAvatarClick
            )
        }

        // 2. Greeting Headline
        item {
            VynoxGreetingSection()
        }

        // 3. Search Bar
        item {
            VynoxSearchBar(
                query = searchQuery,
                onQueryChange = onSearchQueryChange,
                onClear = { onSearchQueryChange("") }
            )
        }

        // 4. Hero Card: "Looking for a Pro? Hire top Vynox Editors"
        item {
            VynoxPromoBanner(
                creators = creators,
                onBrowseClick = onBrowseCreatorsClick,
                onFindEditorsClick = onBrowseCreatorsClick
            )
        }

        // 5. Quick Tools Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quick Tools",
                    color = VynoxTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onSeeAllToolsClick)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "See all",
                        color = VynoxPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "See all",
                        tint = VynoxPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // 6. Quick Tools Grid (2 columns or 4 prominent cards matching the screenshot)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // First Row (e.g. Templates & Auto Edit)
                val row1 = filteredTools.take(2)
                if (row1.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        row1.forEach { tool ->
                            QuickToolCard(
                                tool = tool,
                                onClick = { onToolClick(tool) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(118.dp)
                            )
                        }
                    }
                }

                // Second Row (e.g. AI Studio & AI Video Gen)
                val row2 = filteredTools.drop(2).take(2)
                if (row2.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        row2.forEach { tool ->
                            QuickToolCard(
                                tool = tool,
                                onClick = { onToolClick(tool) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(118.dp)
                            )
                        }
                    }
                }
            }
        }

        // 7. Recent Projects Section
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Projects",
                    color = VynoxTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${projects.size} active",
                    color = VynoxTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(projects) { project ->
                    RecentProjectCard(
                        project = project,
                        onClick = { onProjectClick(project) }
                    )
                }
            }
        }

        // 8. Quick Action Banner: Generate with AI
        item {
            Spacer(modifier = Modifier.height(18.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .clickable(onClick = onOpenAiGenerator)
                    .testTag("home_ai_generator_cta"),
                colors = CardDefaults.cardColors(containerColor = VynoxSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(VynoxPrimary, VynoxSecondary))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartDisplay,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Create with AI Generator",
                                color = VynoxTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Prompt to 4K cinematic video clip",
                                color = VynoxTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Button(
                        onClick = onOpenAiGenerator,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = VynoxSurfaceHighlight),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VynoxPrimary.copy(alpha = 0.5f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Launch",
                            color = VynoxTertiary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RecentProjectCard(
    project: ProjectItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .width(220.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag("project_card_${project.id}"),
        colors = CardDefaults.cardColors(containerColor = VynoxSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder)
    ) {
        Column {
            // Thumbnail Canvas/Gradient
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(Brush.linearGradient(project.gradientColors))
            ) {
                // Play icon overlay
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .align(Alignment.Center),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Open editor",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Duration badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.7f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Text(
                        text = project.duration,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                // Resolution badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = VynoxPrimary.copy(alpha = 0.85f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    Text(
                        text = project.resolution,
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }

            // Project Info
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                Text(
                    text = project.title,
                    color = VynoxTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = project.subtitle,
                    color = VynoxTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = project.timeAgo,
                        color = VynoxTextMuted,
                        fontSize = 10.sp
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = null,
                            tint = VynoxTextMuted,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "${project.collaboratorsCount}",
                            color = VynoxTextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
