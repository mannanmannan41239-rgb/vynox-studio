package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EditorCreator
import com.example.model.VynoxMockData
import com.example.ui.theme.*

@Composable
fun MarketplaceScreen(
    onCreatorClick: (EditorCreator) -> Unit,
    onHireClick: (EditorCreator) -> Unit,
    modifier: Modifier = Modifier
) {
    val creators = remember { VynoxMockData.creators }
    var selectedGenre by remember { mutableStateOf("All") }
    val genres = listOf("All", "Commercial", "Colorist", "Storytelling", "Fashion", "VFX")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VynoxBackground)
            .statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // Title Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Creative Marketplace",
                        color = VynoxTextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Hire vetted industry video editors",
                        color = VynoxTextSecondary,
                        fontSize = 12.sp
                    )
                }

                IconButton(
                    onClick = { /* Filter modal */ },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(VynoxSurfaceElevated)
                        .border(1.dp, VynoxBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Filters",
                        tint = VynoxTextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Filter Pills Row
        item {
            LazyRow(
                modifier = Modifier.padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(genres) { genre ->
                    val isSelected = selectedGenre == genre
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedGenre = genre },
                        label = { Text(genre, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = VynoxSurfaceElevated,
                            labelColor = VynoxTextSecondary,
                            selectedContainerColor = VynoxPrimary,
                            selectedLabelColor = Color.White
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = VynoxBorder,
                            selectedBorderColor = VynoxPrimary
                        )
                    )
                }
            }
        }

        // Section Title: Featured Creators
        item {
            Text(
                text = "Featured Editors",
                color = VynoxTextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
        }

        // Creator Cards
        items(creators) { creator ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onCreatorClick(creator) }
                    .testTag("creator_card_${creator.id}"),
                colors = CardDefaults.cardColors(containerColor = VynoxSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    // Header of card: Avatar, Name, Badge, Rate
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(creator.avatarBgColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = creator.avatarInitials,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = creator.name,
                                        color = VynoxTextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (creator.verified) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "Verified",
                                            tint = VynoxTertiary,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = creator.specialty,
                                    color = VynoxTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // Hourly rate pill
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = VynoxSurfaceHighlight,
                            border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder)
                        ) {
                            Text(
                                text = creator.hourlyRate,
                                color = VynoxTertiary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Portfolio Preview Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(creator.avatarBgColor.copy(alpha = 0.5f), Color(0xFF1E2638))
                                )
                            )
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .align(Alignment.Center),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Text(
                            text = creator.portfolioTitle,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Rating and Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = VynoxAccentAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "${creator.rating}",
                                color = VynoxTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "(${creator.reviewCount} reviews)",
                                color = VynoxTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onCreatorClick(creator) },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = VynoxTextPrimary
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, VynoxBorder),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Portfolio", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { onHireClick(creator) },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = VynoxPrimary
                                ),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text("Hire", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
