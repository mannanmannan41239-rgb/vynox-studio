package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

data class QuickTool(
    val id: String,
    val title: String,
    val subtitle: String,
    val iconType: String,
    val accentColor: Color,
    val badge: String? = null
)

data class EditorCreator(
    val id: String,
    val name: String,
    val specialty: String,
    val rating: Double,
    val reviewCount: Int,
    val hourlyRate: String,
    val avatarInitials: String,
    val avatarBgColor: Color,
    val verified: Boolean = true,
    val isOnline: Boolean = true,
    val portfolioTitle: String,
    val tag: String
)

data class ProjectItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val type: String,
    val duration: String,
    val timeAgo: String,
    val aspectRatio: String = "16:9",
    val resolution: String = "4K 60fps",
    val gradientColors: List<Color>,
    val collaboratorsCount: Int = 1
)

data class AIStudioItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val iconType: String,
    val accentColor: Color,
    val isPro: Boolean = false
)

data class MilestoneItem(
    val id: String,
    val title: String,
    val amount: String,
    val status: String,
    val date: String
)

object VynoxMockData {
    val quickTools = listOf(
        QuickTool("templates", "Templates", "Trendy Presets", "grid", ToolCyan),
        QuickTool("auto_edit", "Auto Edit", "Smart Cut & Pace", "magic", ToolViolet, badge = "AI"),
        QuickTool("ai_studio", "AI Studio", "Neural Video Suite", "ai", ToolIndigo, badge = "NEW"),
        QuickTool("video_gen", "AI Video Gen", "Text to Cinematic", "video", ToolRose),
        QuickTool("upscale", "AI Upscaler", "SD to 4K / 8K", "sparkles", VynoxTertiary),
        QuickTool("color_grade", "Color Grade", "Hollywood LUTs", "palette", ToolAmber),
        QuickTool("smart_trim", "Smart Trim", "Auto Highlights", "scissors", ToolEmerald),
        QuickTool("audio_iso", "Audio Clean", "Voice Isolation", "waveform", ToolCyan)
    )

    val creators = listOf(
        EditorCreator(
            id = "c1",
            name = "Alex Vance",
            specialty = "VFX & Commercial Editor",
            rating = 4.9,
            reviewCount = 142,
            hourlyRate = "$45/hr",
            avatarInitials = "AV",
            avatarBgColor = Color(0xFF6366F1),
            portfolioTitle = "Neon Cyberpunk Promo",
            tag = "Commercial"
        ),
        EditorCreator(
            id = "c2",
            name = "Elena Rostova",
            specialty = "Cinematic Colorist & Reels",
            rating = 5.0,
            reviewCount = 89,
            hourlyRate = "$60/hr",
            avatarInitials = "ER",
            avatarBgColor = Color(0xFFEC4899),
            portfolioTitle = "Sunset Coast Cinematic 4K",
            tag = "Colorist"
        ),
        EditorCreator(
            id = "c3",
            name = "Marcus Chen",
            specialty = "YouTube & Documentary Lead",
            rating = 4.8,
            reviewCount = 210,
            hourlyRate = "$40/hr",
            avatarInitials = "MC",
            avatarBgColor = Color(0xFF10B981),
            portfolioTitle = "Fast-Paced Tech Doc",
            tag = "Storytelling"
        ),
        EditorCreator(
            id = "c4",
            name = "Sarah Jenkins",
            specialty = "Fashion & Music Videos",
            rating = 4.95,
            reviewCount = 67,
            hourlyRate = "$55/hr",
            avatarInitials = "SJ",
            avatarBgColor = Color(0xFF8B5CF6),
            portfolioTitle = "Vogue Runway Edit",
            tag = "Fashion"
        )
    )

    val projects = listOf(
        ProjectItem(
            id = "p1",
            title = "Sunset Waves Cinematic",
            subtitle = "Ocean B-Roll & Color Grade",
            type = "Video",
            duration = "01:29",
            timeAgo = "Edited 2h ago",
            aspectRatio = "16:9",
            resolution = "4K UHD",
            gradientColors = listOf(Color(0xFFEA580C), Color(0xFFC026D3), Color(0xFF3B82F6)),
            collaboratorsCount = 2
        ),
        ProjectItem(
            id = "p2",
            title = "Tokyo Midnight Reel",
            subtitle = "Speed ramp + glitch VFX",
            type = "Reels",
            duration = "00:32",
            timeAgo = "Yesterday",
            aspectRatio = "9:16",
            resolution = "1080p 60fps",
            gradientColors = listOf(Color(0xFF4F46E5), Color(0xFF06B6D4)),
            collaboratorsCount = 1
        ),
        ProjectItem(
            id = "p3",
            title = "Studio Product Showcase",
            subtitle = "3D motion graphics pass",
            type = "Commercial",
            duration = "02:15",
            timeAgo = "3 days ago",
            aspectRatio = "16:9",
            resolution = "4K 60fps",
            gradientColors = listOf(Color(0xFF8B5CF6), Color(0xFF10B981)),
            collaboratorsCount = 3
        )
    )

    val aiTools = listOf(
        AIStudioItem(
            id = "ai1",
            title = "AI Video Generator",
            subtitle = "Text to Ultra-HD Video",
            category = "Generation",
            iconType = "video",
            accentColor = Color(0xFF6366F1),
            isPro = true
        ),
        AIStudioItem(
            id = "ai2",
            title = "AI Video Upscaler",
            subtitle = "SD / 1080p to Pristine 4K",
            category = "Enhance",
            iconType = "upscale",
            accentColor = Color(0xFF06B6D4)
        ),
        AIStudioItem(
            id = "ai3",
            title = "AI Color Grading",
            subtitle = "Hollywood Look & Film Emulation",
            category = "Finishing",
            iconType = "palette",
            accentColor = Color(0xFFF59E0B)
        ),
        AIStudioItem(
            id = "ai4",
            title = "AI Smart Trimmer",
            subtitle = "Auto-detect Highlights & Silence",
            category = "Editing",
            iconType = "scissors",
            accentColor = Color(0xFF10B981)
        ),
        AIStudioItem(
            id = "ai5",
            title = "AI Script Writer",
            subtitle = "Viral Hook & Voiceover Generation",
            category = "Scripting",
            iconType = "script",
            accentColor = Color(0xFF8B5CF6)
        )
    )

    val invoices = listOf(
        MilestoneItem("m1", "Rough Cut v1", "$15.00", "Completed", "Oct 06"),
        MilestoneItem("m2", "Final Color Polish", "$16.50", "Completed", "Oct 07"),
        MilestoneItem("m3", "Sound Design & Master", "$15.00", "Pending", "Oct 08")
    )
}
