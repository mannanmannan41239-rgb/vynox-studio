package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.model.EditorCreator
import com.example.model.ProjectItem
import com.example.model.VynoxMockData
import com.example.ui.components.AiGeneratorSheet
import com.example.ui.components.HireMilestoneDialog
import com.example.ui.components.VynoxBottomNav
import com.example.ui.screens.AIStudioScreen
import com.example.ui.screens.AdvancedEditorScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MarketplaceScreen
import com.example.ui.screens.ProjectHubScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.VynoxBackground
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                VynoxStudioApp()
            }
        }
    }
}

@Composable
fun VynoxStudioApp() {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Navigation State: 0 = Home, 1 = Templates/AI Studio, 2 = Projects, 3 = Marketplace
    var currentTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    // Sub-screens & modals
    var activeEditorProject by remember { mutableStateOf<ProjectItem?>(null) }
    var showAiGeneratorSheet by remember { mutableStateOf(false) }
    var activeHireCreator by remember { mutableStateOf<EditorCreator?>(null) }

    // Handle system back navigation
    BackHandler(enabled = activeEditorProject != null || showAiGeneratorSheet || activeHireCreator != null || currentTab != 0) {
        when {
            showAiGeneratorSheet -> showAiGeneratorSheet = false
            activeHireCreator != null -> activeHireCreator = null
            activeEditorProject != null -> activeEditorProject = null
            currentTab != 0 -> currentTab = 0
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = VynoxBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (activeEditorProject == null) {
                VynoxBottomNav(
                    selectedTab = currentTab,
                    onTabSelected = { currentTab = it }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = if (activeEditorProject == null) innerPadding.calculateBottomPadding() else androidx.compose.ui.unit.Dp(0f))
        ) {
            if (activeEditorProject != null) {
                AdvancedEditorScreen(
                    project = activeEditorProject!!,
                    onBack = { activeEditorProject = null },
                    onExport = {
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Video project exported successfully!")
                        }
                    }
                )
            } else {
                when (currentTab) {
                    0 -> HomeScreen(
                        searchQuery = searchQuery,
                        onSearchQueryChange = { searchQuery = it },
                        onToolClick = { tool ->
                            when (tool.id) {
                                "ai_studio", "video_gen", "upscale" -> {
                                    showAiGeneratorSheet = true
                                }
                                "templates" -> {
                                    currentTab = 1
                                }
                                "auto_edit", "smart_trim" -> {
                                    activeEditorProject = VynoxMockData.projects.first()
                                }
                                else -> {
                                    showAiGeneratorSheet = true
                                }
                            }
                        },
                        onSeeAllToolsClick = { currentTab = 1 },
                        onBrowseCreatorsClick = { currentTab = 3 },
                        onProjectClick = { project -> activeEditorProject = project },
                        onCreateProjectClick = {
                            activeEditorProject = VynoxMockData.projects.first()
                        },
                        onOpenAiGenerator = { showAiGeneratorSheet = true },
                        onAvatarClick = {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("VYNOX Pro Member • All Studio AI features unlocked")
                            }
                        }
                    )
                    1 -> AIStudioScreen(
                        onToolClick = { _ -> showAiGeneratorSheet = true },
                        onBack = { currentTab = 0 }
                    )
                    2 -> ProjectHubScreen(
                        onProjectClick = { project -> activeEditorProject = project },
                        onCreateNewClick = {
                            activeEditorProject = VynoxMockData.projects.first()
                        }
                    )
                    3 -> MarketplaceScreen(
                        onCreatorClick = { creator ->
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Viewing portfolio: ${creator.portfolioTitle}")
                            }
                        },
                        onHireClick = { creator ->
                            activeHireCreator = creator
                        }
                    )
                }
            }

            // AI Generator Bottom Sheet
            if (showAiGeneratorSheet) {
                AiGeneratorSheet(
                    onDismiss = { showAiGeneratorSheet = false }
                )
            }

            // Hire / Milestone Dialog
            if (activeHireCreator != null) {
                HireMilestoneDialog(
                    creator = activeHireCreator!!,
                    onDismiss = { activeHireCreator = null },
                    onPaymentSuccess = {
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Funds added to Escrow for ${activeHireCreator?.name}")
                        }
                    }
                )
            }
        }
    }
}
