package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("VYNOX Studio", appName)
  }

  @Test
  fun `verify quick tools and mock data exist`() {
    val tools = com.example.model.VynoxMockData.quickTools
    val creators = com.example.model.VynoxMockData.creators
    assertEquals(8, tools.size)
    assertEquals(4, creators.size)
  }
}
